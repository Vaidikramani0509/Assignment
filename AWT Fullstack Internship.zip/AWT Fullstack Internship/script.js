var typed = new Typed(".animationtext", {
    strings: ["frontend developer", "Youtuber", "web developer"],
    typeSpeed: 100,
    backSpeed: 50,
    backDelay: 1000,
    loop: true
});